CREATE DATABASE IF NOT EXISTS TechWorld;
USE TechWorld;

CREATE TABLE Clientes (
    cliente_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100),
    direccion VARCHAR(255),
    telefono VARCHAR(20),
    email VARCHAR(100),
    fecha_registro DATE
);

CREATE TABLE Proveedores (
    proveedor_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100),
    direccion VARCHAR(255),
    telefono VARCHAR(20),
    email VARCHAR(100),
    fecha_registro DATE
);

CREATE TABLE Productos (
    producto_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100),
    descripcion TEXT,
    precio DECIMAL(10, 2),
    cantidad INT,
    proveedor_id INT,
    FOREIGN KEY (proveedor_id) REFERENCES Proveedores(proveedor_id)
);

CREATE TABLE Empleados (
    empleado_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100),
    puesto VARCHAR(50),
    salario DECIMAL(10, 2),
    fecha_ingreso DATE
);

CREATE TABLE Almacenes (
    almacen_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100),
    direccion VARCHAR(255)
);

CREATE TABLE Inventario (
    inventario_id INT PRIMARY KEY AUTO_INCREMENT,
    producto_id INT,
    almacen_id INT,
    cantidad_stock INT,
    FOREIGN KEY (producto_id) REFERENCES Productos(producto_id),
    FOREIGN KEY (almacen_id) REFERENCES Almacenes(almacen_id)
);

CREATE TABLE Ventas (
    venta_id INT PRIMARY KEY AUTO_INCREMENT,
    cliente_id INT,
    empleado_id INT,
    fecha_venta DATE,
    total DECIMAL(10, 2),
    FOREIGN KEY (cliente_id) REFERENCES Clientes(cliente_id),
    FOREIGN KEY (empleado_id) REFERENCES Empleados(empleado_id)
);

CREATE TABLE DetalleVentas (
    detalleventa_id INT PRIMARY KEY AUTO_INCREMENT,
    venta_id INT,
    producto_id INT,
    cantidad INT,
    precio_unitario DECIMAL(10, 2),
    FOREIGN KEY (venta_id) REFERENCES Ventas(venta_id),
    FOREIGN KEY (producto_id) REFERENCES Productos(producto_id)
);

CREATE TABLE Compras (
    compra_id INT PRIMARY KEY AUTO_INCREMENT,
    proveedor_id INT,
    empleado_id INT,
    fecha_compra DATE,
    total DECIMAL(10, 2),
    FOREIGN KEY (proveedor_id) REFERENCES Proveedores(proveedor_id),
    FOREIGN KEY (empleado_id) REFERENCES Empleados(empleado_id)
);

CREATE TABLE DetalleCompras (
    detallecompra_id INT PRIMARY KEY AUTO_INCREMENT,
    compra_id INT,
    producto_id INT,
    cantidad INT,
    precio_unitario DECIMAL(10, 2),
    FOREIGN KEY (compra_id) REFERENCES Compras(compra_id),
    FOREIGN KEY (producto_id) REFERENCES Productos(producto_id)
);

CREATE TABLE Escandallos (
    escandallo_id INT PRIMARY KEY AUTO_INCREMENT,
    producto_compuesto_id INT,
    producto_simple_id INT,
    cantidad_necesaria INT NOT NULL,
    FOREIGN KEY (producto_compuesto_id) REFERENCES Productos(producto_id) ON DELETE CASCADE,
    FOREIGN KEY (producto_simple_id) REFERENCES Productos(producto_id) ON DELETE CASCADE
);

INSERT INTO empleados (nombre, puesto, salario, fecha_ingreso) VALUES ('Jorge', 'Ingeniero', 1000.00, '2022-09-21'); 
INSERT INTO empleados (nombre, puesto, salario, fecha_ingreso) VALUES ('Alejandro', 'Cajero', 700.00, '2023-06-06'); 
INSERT INTO empleados (nombre, puesto, salario, fecha_ingreso) VALUES ('Gonzalo', 'Reparador', 1300.00, '2023-09-08');