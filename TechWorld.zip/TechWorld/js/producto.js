let i = 0

document.getElementById('b1').addEventListener("click", function() {
    create()
})

const create = () => {
    if(i<1) {
        var popup = document.getElementById("padre")
        popup.removeAttribute("class", "hide")
        popup.setAttribute("class", "popup")

        var form = document.createElement("form")
        form.setAttribute("action", "../controller/ProductoController.php?accion=insertar")
        form.setAttribute("method", "post")
        form.setAttribute("class", "insert")

        var input1 = document.createElement("input")
        input1.setAttribute("type", "text")
        input1.setAttribute("name", "nombre")
        input1.setAttribute("placeholder", "Nombre")
        input1.setAttribute("required", "true")
        input1.setAttribute("class", "form_post")
        form.appendChild(input1)

        var input2 = document.createElement("input")
        input2.setAttribute("type", "text")
        input2.setAttribute("name", "descripcion")
        input2.setAttribute("placeholder", "Descripción")
        input2.setAttribute("required", "true")
        input2.setAttribute("class", "form_post")
        form.appendChild(input2)

        var input3 = document.createElement("input")
        input3.setAttribute("type", "number")
        input3.setAttribute("name", "precio")
        input3.setAttribute("placeholder", "Precio")
        input3.setAttribute("required", "true")
        input3.setAttribute("class", "form_post")
        form.appendChild(input3)

        var input4 = document.createElement("input")
        input4.setAttribute("type", "number")
        input4.setAttribute("name", "cantidad_stock")
        input4.setAttribute("placeholder", "Stock")
        input4.setAttribute("required", "true")
        input4.setAttribute("class", "form_post")
        form.appendChild(input4)

        var input5 = document.createElement("input")
        input5.setAttribute("type", "text")
        input5.setAttribute("name", "tipo")
        input5.setAttribute("placeholder", "Simple/Compuesto")
        input5.setAttribute("required", "true")
        input5.setAttribute("class", "form_post")
        form.appendChild(input5)

        var submit = document.createElement("button")
        submit.setAttribute("type", "submit")
        submit.setAttribute("class", "crud")
        submit.setAttribute("id", "insert")
        submit.textContent = "Guardar"
        form.appendChild(submit)

        document.getElementById("padre").appendChild(form)
        i++
    }
}

form.addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Formulario enviado");
});