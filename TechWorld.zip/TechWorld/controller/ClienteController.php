<?php
require_once '../db/techworld.php';
require_once '../model/ClienteModel.php';

$clienteModel = new ClienteModel($conn);

// Comprobar si hay una acción en la petición (insertar, buscar, actualizar, eliminar)
$accion = isset($_GET['accion']) ? $_GET['accion'] : '';

switch ($accion) {
    case 'insertar':
        if (isset($_POST['nombre'], $_POST['direccion'], $_POST['telefono'], $_POST['email'], $_POST['fecha_registro'])) {
            $nombre = $_POST['nombre'];
            $direccion = $_POST['direccion'];
            $telefono = $_POST['telefono'];
            $email = $_POST['email'];
            $fecha_registro = $_POST['fecha_registro'];

            if ($clienteModel->insertar($nombre, $direccion, $telefono, $email, $fecha_registro)) {
                echo "Cliente agregado correctamente.";
            } else {
                echo "Error al agregar el cliente.";
            }
        }
        header("Location: ../view/clientes.php");
        exit();
        break;

    case 'buscar':
        if (isset($_GET['nombre'])) {
            $nombre = $_GET['nombre'];
            $clientes = $clienteModel->obtenerPorNombre($nombre);

            if (!empty($clientes)) {
                echo "Clientes encontrados:<br>";
                foreach ($clientes as $cliente) {
                    echo $cliente["nombre"] . " - " . $cliente["direccion"] . " - " . $cliente["telefono"] . " - " . $cliente["email"] . " - " . $cliente["fecha_registro"] . "<br>";
                }
            } else {
                echo "No se encontraron clientes con ese nombre.";
            }
        }
        break;

    case 'actualizar':
        if (isset($_POST['cliente_id'], $_POST['nombre'], $_POST['direccion'], $_POST['telefono'], $_POST['email'], $_POST['fecha_registro'])) {
            $cliente_id = $_POST['cliente_id'];
            $nombre = $_POST['nombre'];
            $direccion = $_POST['direccion'];
            $telefono = $_POST['telefono'];
            $email = $_POST['email'];
            $fecha_registro = $_POST['fecha_registro'];

            if ($clienteModel->actualizar($cliente_id, $nombre, $direccion, $telefono, $email, $fecha_registro)) {
                echo "Cliente actualizado correctamente.";
            } else {
                echo "Error al actualizar el cliente.";
            }
        }
        header("Location: ../view/clientes.php");
        exit();
        break;

    case 'eliminar':
        if (isset($_GET['cliente_id'])) {
            $cliente_id = $_GET['cliente_id'];
            if ($clienteModel->eliminar($cliente_id)) {
                echo "Cliente eliminado correctamente.";
            } else {
                echo "Error al eliminar el cliente.";
            }
        }
        header("Location: ../view/clientes.php");
        exit();
        break;

    default:
        if (!empty($accion)) {
            echo "Acceso inválido.";
        }
        break;
}
?>
