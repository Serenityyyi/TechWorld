<?php
require_once '../db/techworld.php';
require_once '../model/ProductoModel.php';

$productoModel = new ProductoModel($conn);

// Comprobar si hay una acción en la petición (insertar, buscar, actualizar, eliminar)
$accion = isset($_GET['accion']) ? $_GET['accion'] : '';

switch ($accion) {
    case 'insertar':
        if (isset($_POST['nombre'], $_POST['descripcion'], $_POST['precio'], $_POST['cantidad_stock'], $_POST['tipo'])) {
            $nombre = $_POST['nombre'];
            $descripcion = $_POST['descripcion'];
            $precio = $_POST['precio'];
            $cantidad_stock = $_POST['cantidad_stock'];
            $tipo = $_POST['tipo'];

            if ($productoModel->insertar($nombre, $descripcion, $precio, $cantidad_stock, $tipo)) {
                echo "producto agregado correctamente.";
            } else {
                echo "Error al agregar el producto.";
            }
        }
        header("Location: ../view/productos.php");
        exit();
        break;

    case 'buscar':
        if (isset($_GET['nombre'])) {
            $nombre = $_GET['nombre'];
            $producto = $productoModel->obtenerPorNombre($nombre);

            if (!empty($productos)) {
                echo "Productos encontrados:<br>";
                foreach ($productos as $producto) {
                    echo $producto["nombre"] . " - " . $producto["descripcion"] . " - " . $producto["precio"] . " - " . $producto["cantidad_stock"] . " - " . $producto["tipo"] . "<br>";
                }
            } else {
                echo "No se encontraron productos con ese nombre.";
            }
        }
        break;

    case 'actualizar':
        if (isset($_POST['producto_id'], $_POST['nombre'], $_POST['descripcion'], $_POST['precio'], $_POST['cantidad_stock'], $_POST['tipo'])) {
            $producto_id = $_POST['producto_id'];
            $nombre = $_POST['nombre'];
            $descripcion = $_POST['descripcion'];
            $precio = $_POST['precio'];
            $cantidad_stock = $_POST['cantidad_stock'];
            $tipo = $_POST['tipo'];

            if ($productoModel->actualizar($producto_id, $nombre, $descripcion, $precio, $cantidad_stock, $tipo)) {
                echo "Producto actualizado correctamente.";
            } else {
                echo "Error al actualizar el producto.";
            }
        }
        header("Location: ../view/productos.php");
        exit();
        break;

    case 'eliminar':
        if (isset($_GET['producto_id'])) {
            $producto_id = $_GET['producto_id'];
            if ($productoModel->eliminar($producto_id)) {
                echo "producto eliminado correctamente.";
            } else {
                echo "Error al eliminar el producto.";
            }
        }
        header("Location: ../view/productos.php");
        exit();
        break;

    default:
        if (!empty($accion)) {
            echo "Acceso inválido.";
        }
        break;
}
?>
