<?php
require_once '../db/techworld.php';
require_once '../model/EmpleadoModel.php';

$empleadoModel = new EmpleadoModel($conn);

// Comprobar si hay una acción en la petición (insertar, buscar, actualizar, eliminar)
$accion = isset($_GET['accion']) ? $_GET['accion'] : '';

switch ($accion) {
    case 'insertar':
        if (isset($_POST['nombre'], $_POST['puesto'], $_POST['salario'], $_POST['fecha_ingreso'])) {
            $nombre = $_POST['nombre'];
            $puesto = $_POST['puesto'];
            $salario = $_POST['salario'];
            $fecha_ingreso = $_POST['fecha_ingreso'];

            if ($empleadoModel->insertar($nombre, $puesto, $salario, $fecha_ingreso)) {
                echo "Empleado agregado correctamente.";
            } else {
                echo "Error al agregar el empleado.";
            }
        }
        header("Location: ../view/empleados.php");
        exit();
        break;

    case 'buscar':
        if (isset($_GET['nombre'])) {
            $nombre = $_GET['nombre'];
            $empleados = $empleadoModel->obtenerPorNombre($nombre);

            if (!empty($empleados)) {
                echo "Empleados encontrados:<br>";
                foreach ($empleados as $empleado) {
                    echo $empleado["nombre"] . " - " . $empleado["puesto"] . " - $" . $empleado["salario"] . "<br>";
                }
            } else {
                echo "No se encontraron empleados con ese nombre.";
            }
        }
        break;

    case 'actualizar':
        if (isset($_POST['empleado_id'], $_POST['nombre'], $_POST['puesto'], $_POST['salario'], $_POST['fecha_ingreso'])) {
            $empleado_id = $_POST['empleado_id'];
            $nombre = $_POST['nombre'];
            $puesto = $_POST['puesto'];
            $salario = $_POST['salario'];
            $fecha_ingreso = $_POST['fecha_ingreso'];

            if ($empleadoModel->actualizar($empleado_id, $nombre, $puesto, $salario, $fecha_ingreso)) {
                echo "Empleado actualizado correctamente.";
            } else {
                echo "Error al actualizar el empleado.";
            }
        }
        header("Location: ../view/empleados.php");
        exit();
        break;

    case 'eliminar':
        if (isset($_GET['empleado_id'])) {
            $empleado_id = $_GET['empleado_id'];
            if ($empleadoModel->eliminar($empleado_id)) {
                echo "Empleado eliminado correctamente.";
            } else {
                echo "Error al eliminar el empleado.";
            }
        }
        header("Location: ../view/empleados.php");
        exit();
        break;

    default:
        if (!empty($accion)) {
            echo "Acceso inválido.";
        }
        break;
}
?>
