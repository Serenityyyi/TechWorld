<?php
require_once '../db/techworld.php';
require_once '../model/ProveedorModel.php';

$proveedorModel = new ProveedorModel($conn);

// Comprobar si hay una acción en la petición (insertar, buscar, actualizar, eliminar)
$accion = isset($_GET['accion']) ? $_GET['accion'] : '';

switch ($accion) {
    case 'insertar':
        if (isset($_POST['nombre'], $_POST['direccion'], $_POST['telefono'], $_POST['email'], $_POST['fecha_registro'])) {
            $nombre = $_POST['nombre'];
            $direccion = $_POST['direccion'];
            $telefono = $_POST['telefono'];
            $email = $_POST['email'];
            $fecha_registro = $_POST['fecha_registro'];

            if ($proveedorModel->insertar($nombre, $direccion, $telefono, $email, $fecha_registro)) {
                echo "proveedor agregado correctamente.";
            } else {
                echo "Error al agregar el proveedor.";
            }
        }
        header("Location: ../view/proveedores.php");
        exit();
        break;

    case 'buscar':
        if (isset($_GET['nombre'])) {
            $nombre = $_GET['nombre'];
            $proveedor = $proveedorModel->obtenerPorNombre($nombre);

            if (!empty($proveedores)) {
                echo "Proveedores encontrados:<br>";
                foreach ($proveedores as $proveedor) {
                    echo $proveedor["nombre"] . " - " . $proveedor["direccion"] . " - " . $proveedor["telefono"] . " - " . $proveedor["email"] . " - " . $proveedor["fecha_registro"] . "<br>";
                }
            } else {
                echo "No se encontraron proveedores con ese nombre.";
            }
        }
        break;

    case 'actualizar':
        if (isset($_POST['proveedor_id'], $_POST['nombre'], $_POST['direccion'], $_POST['telefono'], $_POST['email'], $_POST['fecha_registro'])) {
            $proveedor_id = $_POST['proveedor_id'];
            $nombre = $_POST['nombre'];
            $direccion = $_POST['direccion'];
            $telefono = $_POST['telefono'];
            $email = $_POST['email'];
            $fecha_registro = $_POST['fecha_registro'];

            if ($proveedorModel->actualizar($proveedor_id, $nombre, $direccion, $telefono, $email, $fecha_registro)) {
                echo "Proveedor actualizado correctamente.";
            } else {
                echo "Error al actualizar el proveedor.";
            }
        }
        header("Location: ../view/proveedores.php");
        exit();
        break;

    case 'eliminar':
        if (isset($_GET['proveedor_id'])) {
            $proveedor_id = $_GET['proveedor_id'];
            if ($proveedorModel->eliminar($proveedor_id)) {
                echo "Proveedor eliminado correctamente.";
            } else {
                echo "Error al eliminar el proveedor.";
            }
        }
        header("Location: ../view/proveedores.php");
        exit();
        break;

    default:
        if (!empty($accion)) {
            echo "Acceso inválido.";
        }
        break;
}
?>
