<?php
    require_once '../controller/EmpleadoController.php';

    $empleados = $empleadoModel->obtenerTodos();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/back/back_styles.css">
    <script src="../js/motor.js" defer></script>
</head>
<body>
<nav>
        <div class="nav1">
            <div class="logo">
                <img src="../img/logo.png" alt="Techworld">
            </div>
            <div class="home">
                <img src="../img/home.png" alt="home" id="house" onclick="window.location.href='index.php'">
                <button onclick="window.location.href='logout.php'" id="logout" class="button">Cerrar sesión</button>
            </div>
        </div>

        <div class="nav2">
            <button onclick="window.location.href='empleados.php'" class="button">Empleados</button>
            <button onclick="window.location.href='clientes.php'" class="button">Clientes</button>
            <button onclick="window.location.href='proveedores.php'" class="button">Proveedores</button>
            <button onclick="window.location.href='productos.php'" class="button">Productos</button>
            <button onclick="window.location.href='compras.php'" class="button">Compras</button>
            <button onclick="window.location.href='ventas.php'" class="button">Ventas</button>
            <button onclick="window.location.href='almacenes.php'" class="button">Almacenes</button>
            <button onclick="window.location.href='inventario.php'" class="button">Inventario</button>
            <button onclick="window.location.href='escandallos.php'" class="button">Escandallos</button>
        </div>

        <div class="nav3">
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
            <button onclick="window.location.href='detallecompras.php'" id="details" class="button">Detalles</button>
            <button onclick="window.location.href='detalleventas.php'" id="details" class="button">Detalles</button>
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
        </div>
        <hr>
    </nav>
    <div class="consult">
        <div class="search">
            <form action="" method="get" class="form_search">
                <input type="text" class="read" name="nombre" placeholder="Buscar por nombre del empleado">
                <div>
                <button type="submit" class="crud">Buscar</button>
                </div>
            </form>
            <button class="crud" id="b1">Crear usuario</button>
        </div>
        

        <?php
            // Si hay una búsqueda, mostrar resultados
        if (isset($_GET['nombre']) && !empty($_GET['nombre'])) {
            $nombreBuscado = $_GET['nombre'];
            $resultadoBusqueda = $empleadoModel->obtenerPorNombre($nombreBuscado);

            if (!empty($resultadoBusqueda)) {
                echo "<table>";
                echo "<tr><th>Nombre</th><th>Puesto</th><th>Salario</th><th>Fecha Ingreso</th><th>Acciones</th></tr>";
                foreach ($resultadoBusqueda as $empleado) {
                    echo "<tr>
                            <td>{$empleado['nombre']}</td>
                            <td>{$empleado['puesto']}</td>
                            <td>\${$empleado['salario']}</td>
                            <td>{$empleado['fecha_ingreso']}</td>
                            <td>
                                <a href='empleados.php?editar={$empleado['empleado_id']}'>Editar</a> |
                                <a href='../controller/EmpleadoController.php?accion=eliminar&empleado_id={$empleado['empleado_id']}' onclick='return confirm(\"¿Seguro que quieres eliminar este empleado?\");'>Eliminar</a>
                            </td>
                        </tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No se encontraron empleados con ese nombre.</p>";
            }
        }

        ?>
        <!--<table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Puesto</th>
                    <th>Salario</th>
                    <th>Fecha de ingreso</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table> -->
    </div>
    <?php
    // Si se quiere editar un empleado, mostrar el formulario de edición
    if (isset($_GET['editar'])) {
        $idEditar = $_GET['editar'];
        $empleadoEditar = null;

        foreach ($empleados as $empleado) {
            if ($empleado['empleado_id'] == $idEditar) {
                $empleadoEditar = $empleado;
                break;
            }
        }

        if ($empleadoEditar):
    ?>
        <div class="edit">
            <h3>Editar Empleado</h3>
            <form action="../controller/EmpleadoController.php?accion=actualizar" method="post" class="edit_form">
                <input type="hidden" name="empleado_id" value="<?= $empleadoEditar['empleado_id'] ?>">
                <div class="edit_item">
                    <label for="nombre">Nombre</label>
                    <input type="text" name="nombre" value="<?= $empleadoEditar['nombre'] ?>" required class="edit_input" id="nombre">
                </div>
                <div class="edit_item">
                    <label for="puesto">Puesto</label>
                    <input type="text" name="puesto" value="<?= $empleadoEditar['puesto'] ?>" required class="edit_input" id="puesto">
                </div>
                
                <div class="edit_item">
                    <label for="salario">Salario</label>
                    <input type="number" name="salario" value="<?= $empleadoEditar['salario'] ?>" required class="edit_input" id="salario">
                </div>
                <div class="edit_item">
                    <label for="date">Fecha de ingreso</label>
                    <input type="date" name="fecha_ingreso" value="<?= $empleadoEditar['fecha_ingreso'] ?>" required class="edit_input" id="date">
                </div>
                <button type="submit" class="edit_button">Actualizar</button>
            </form>
        </div>
    <?php
        endif;
    }
    ?>
    <div class="popup, hide" id="padre">
        <!--<form action="../controller/EmpleadoController.php?accion=insertar" method="post" class="insert">
            <input type="text" name="nombre" placeholder="Nombre" required class="form_post">
            <input type="text" name="puesto" placeholder="Puesto" required class="form_post">
            <input type="number" name="salario" placeholder="Salario" required class="form_post">
            <input type="date" name="fecha_ingreso" required class="form_post">
            <button type="submit" class="crud" id="insert">Guardar</button>
        </form> -->
    </div>
</body>
</html>