<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>
<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Bienvenido al MVC</title>
    <link rel="stylesheet" href="../css/back/back_styles.css">
</head>
<body>
    <nav>
        <div class="nav1">
            <div class="logo">
                <img src="../img/logo.png" alt="Techworld">
            </div>
            <div class="home">
                <img src="../img/home.png" alt="home" id="house" onclick="window.location.href='index.php'">
                <button onclick="window.location.href='logout.php'" id="logout" class="button">Cerrar sesión</button>
            </div>
        </div>

        <div class="nav2">
            <button onclick="window.location.href='empleados.php'" class="button">Empleados</button>
            <button onclick="window.location.href='clientes.php'" class="button">Clientes</button>
            <button onclick="window.location.href='proveedores.php'" class="button">Proveedores</button>
            <button onclick="window.location.href='productos.php'" class="button">Productos</button>
            <button onclick="window.location.href='compras.php'" class="button">Compras</button>
            <button onclick="window.location.href='ventas.php'" class="button">Ventas</button>
            <button onclick="window.location.href='almacenes.php'" class="button">Almacenes</button>
            <button onclick="window.location.href='inventario.php'" class="button">Inventario</button>
            <button onclick="window.location.href='escandallos.php'" class="button">Escandallos</button>
        </div>

        <div class="nav3">
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
            <button onclick="window.location.href='detallecompras.php'" id="details" class="button">Detalles</button>
            <button onclick="window.location.href='detalleventas.php'" id="details" class="button">Detalles</button>
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
        </div>
        <hr>
    </nav>
    <main>
        <section>
            <h2>Ventas del día</h2>
            <div class="info"></div>
        </section>
        <section>
            <h2>Stock bajo</h2>
            <div class="info"></div>
        </section>
        <section>
            <h2>Pedidos pendientes</h2>
            <div class="info"></div>
        </section>
    </main>
</body>
</html>

