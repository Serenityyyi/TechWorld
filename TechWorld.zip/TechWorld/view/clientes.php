<?php
    require_once '../controller/ClienteController.php';

    $clientes = $clienteModel->obtenerTodos();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/back/back_styles.css">
    <script src="../js/cliente.js" defer></script>
</head>
<body>
    <nav>
        <div class="nav1">
            <div class="logo">
                <img src="../img/logo.png" alt="Techworld">
            </div>
            <div class="home">
                <img src="../img/home.png" alt="home" id="house" onclick="window.location.href='index.php'">
                <button onclick="window.location.href='logout.php'" id="logout" class="button">Cerrar sesión</button>
            </div>
        </div>

        <div class="nav2">
            <button onclick="window.location.href='empleados.php'" class="button">Empleados</button>
            <button onclick="window.location.href='clientes.php'" class="button">Clientes</button>
            <button onclick="window.location.href='proveedores.php'" class="button">Proveedores</button>
            <button onclick="window.location.href='productos.php'" class="button">Productos</button>
            <button onclick="window.location.href='compras.php'" class="button">Compras</button>
            <button onclick="window.location.href='ventas.php'" class="button">Ventas</button>
            <button onclick="window.location.href='almacenes.php'" class="button">Almacenes</button>
            <button onclick="window.location.href='inventario.php'" class="button">Inventario</button>
            <button onclick="window.location.href='escandallos.php'" class="button">Escandallos</button>
        </div>

        <div class="nav3">
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
            <button onclick="window.location.href='detallecompras.php'" id="details" class="button">Detalles</button>
            <button onclick="window.location.href='detalleventas.php'" id="details" class="button">Detalles</button>
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
            <button id="hide" class="button"></button>
        </div>
        <hr>
    </nav>
    <div class="consult">
        <div class="search">
            <form action="" method="get" class="form_search">
                <input type="text" class="read" name="nombre" placeholder="Buscar por nombre del cliente">
                <div>
                <button type="submit" class="crud">Buscar</button>
                </div>
            </form>
            <button class="crud" id="b1">Crear cliente</button>
        </div>
        

        <?php
            // Si hay una búsqueda, mostrar resultados
        if (isset($_GET['nombre']) && !empty($_GET['nombre'])) {
            $nombreBuscado = $_GET['nombre'];
            $resultadoBusqueda = $clienteModel->obtenerPorNombre($nombreBuscado);

            if (!empty($resultadoBusqueda)) {
                echo "<table>";
                echo "<tr><th>Nombre</th><th>Dirección</th><th>Teléfono</th><th>Email</th><th>Fecha Registro</th><th>Acciones</th></tr>";
                foreach ($resultadoBusqueda as $cliente) {
                    echo "<tr>
                            <td>{$cliente['nombre']}</td>
                            <td>{$cliente['direccion']}</td>
                            <td>{$cliente['telefono']}</td>
                            <td>{$cliente['email']}</td>
                            <td>{$cliente['fecha_registro']}</td>
                            <td>
                                <a href='clientes.php?editar={$cliente['cliente_id']}'>Editar</a> |
                                <a href='../controller/ClienteController.php?accion=eliminar&cliente_id={$cliente['cliente_id']}' onclick='return confirm(\"¿Seguro que quieres eliminar este cliente?\");'>Eliminar</a>
                            </td>
                        </tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No se encontraron clientes con ese nombre.</p>";
            }
        }

        ?>
    </div>
    <?php
    // Si se quiere editar un cliente, mostrar el formulario de edición
    if (isset($_GET['editar'])) {
        $idEditar = $_GET['editar'];
        $clienteEditar = null;

        foreach ($clientes as $cliente) {
            if ($cliente['cliente_id'] == $idEditar) {
                $clienteEditar = $cliente;
                break;
            }
        }

        if ($clienteEditar):
    ?>
        <div class="edit">
            <h3>Editar Cliente</h3>
            <form action="../controller/ClienteController.php?accion=actualizar" method="post" class="edit_form">
                <input type="hidden" name="cliente_id" value="<?= $clienteEditar['cliente_id'] ?>">
                <div class="edit_item">
                    <label for="nombre">Nombre</label>
                    <input type="text" name="nombre" value="<?= $clienteEditar['nombre'] ?>" required class="edit_input" id="nombre">
                </div>
                <div class="edit_item">
                    <label for="direccion">Dirección</label>
                    <input type="text" name="direccion" value="<?= $clienteEditar['direccion'] ?>" required class="edit_input" id="direccion">
                </div>
                <div class="edit_item">
                    <label for="telefono">Teléfono</label>
                    <input type="number" name="telefono" value="<?= $clienteEditar['telefono'] ?>" required class="edit_input" id="telefono">
                </div>
                <div class="edit_item">
                    <label for="email">Email</label>
                    <input type="text" name="email" value="<?= $clienteEditar['email'] ?>" required class="edit_input" id="email">
                </div>
                <div class="edit_item">
                    <label for="date">Fecha de registro</label>
                    <input type="date" name="fecha_registro" value="<?= $clienteEditar['fecha_registro'] ?>" required class="edit_input" id="date">
                </div>
                <button type="submit" class="edit_button">Actualizar</button>
            </form>
        </div>
    <?php
        endif;
    }
    ?>
    <div class="popup, hide" id="padre">
        <!--<form action="../controller/EmpleadoController.php?accion=insertar" method="post" class="insert">
            <input type="text" name="nombre" placeholder="Nombre" required class="form_post">
            <input type="text" name="puesto" placeholder="Puesto" required class="form_post">
            <input type="number" name="salario" placeholder="Salario" required class="form_post">
            <input type="date" name="fecha_ingreso" required class="form_post">
            <button type="submit" class="crud" id="insert">Guardar</button>
        </form> -->
    </div>
</body>
</html>