<?php
require_once '../db/techworld.php';

class ClienteModel {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    // Insertar un cliente
    public function insertar($nombre, $direccion, $telefono, $email, $fecha_registro) {
        $sql = "INSERT INTO clientes (nombre, direccion, telefono, email, fecha_registro) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssiss", $nombre, $direccion, $telefono, $email, $fecha_registro);
        return $stmt->execute();
    }

    // Obtener todos los clientes
    public function obtenerTodos() {
        $sql = "SELECT * FROM clientes";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Obtener un cliente por nombre
    public function obtenerPorNombre($nombre) {
        $sql = "SELECT * FROM clientes WHERE nombre LIKE ?";
        $stmt = $this->conn->prepare($sql);
        $nombre = "%" . $nombre . "%";
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Actualizar un cliente
    public function actualizar($cliente_id, $nombre, $direccion, $telefono, $email, $fecha_registro) {
        $sql = "UPDATE clientes SET nombre = ?, direccion = ?, telefono = ?, email = ?, fecha_registro = ? WHERE cliente_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssissi", $nombre, $direccion, $telefono, $email, $fecha_registro, $cliente_id);
        return $stmt->execute();
    }

    // Eliminar un cliente
    public function eliminar($cliente_id) {
        $sql = "DELETE FROM clientes WHERE cliente_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $cliente_id);
        return $stmt->execute();
    }
}
?>