<?php
require_once '../db/techworld.php';

class ProductoModel {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    // Insertar un producto
    public function insertar($nombre, $descripcion, $precio, $cantidad_stock, $tipo) {
        $tipo = strtolower(trim($tipo));
        if ($tipo === "compuesto" || $tipo === "simple") {
            $sql = "INSERT INTO productos (nombre, descripcion, precio, cantidad_stock, tipo) VALUES (?, ?, ?, ?, ?)";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("ssiis", $nombre, $descripcion, $precio, $cantidad_stock, $tipo);
            if ($stmt->execute()) {
                echo "Producto agregado correctamente.";
            } else {
                echo "Error al agregar el producto.";
            }
        } else {
            echo "Error: El tipo debe ser 'compuesto' o 'simple'.";
        }
    }

    // Obtener todos los productos
    public function obtenerTodos() {
        $sql = "SELECT * FROM productos";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Obtener un producto por nombre
    public function obtenerPorNombre($nombre) {
        $sql = "SELECT * FROM productos WHERE nombre LIKE ?";
        $stmt = $this->conn->prepare($sql);
        $nombre = "%" . $nombre . "%";
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Actualizar un producto
    public function actualizar($producto_id, $nombre, $descripcion, $precio, $cantidad_stock, $tipo) {
        $sql = "UPDATE productos SET nombre = ?, descripcion = ?, precio = ?, cantidad_stock = ?, tipo = ? WHERE producto_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssiisi", $nombre, $descripcion, $precio, $cantidad_stock, $tipo, $producto_id);
        return $stmt->execute();
    }

    // Eliminar un producto
    public function eliminar($producto_id) {
        $sql = "DELETE FROM productos WHERE producto_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $producto_id);
        return $stmt->execute();
    }
}
?>