<?php
require_once '../db/techworld.php';

class ProveedorModel {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    // Insertar un Proveedor
    public function insertar($nombre, $direccion, $telefono, $email, $fecha_registro) {
        $sql = "INSERT INTO proveedores (nombre, direccion, telefono, email, fecha_registro) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssiss", $nombre, $direccion, $telefono, $email, $fecha_registro);
        return $stmt->execute();
    }

    // Obtener todos los proveedores
    public function obtenerTodos() {
        $sql = "SELECT * FROM proveedores";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Obtener un proveedor por nombre
    public function obtenerPorNombre($nombre) {
        $sql = "SELECT * FROM proveedores WHERE nombre LIKE ?";
        $stmt = $this->conn->prepare($sql);
        $nombre = "%" . $nombre . "%";
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Actualizar un proveedor
    public function actualizar($proveedor_id, $nombre, $direccion, $telefono, $email, $fecha_registro) {
        $sql = "UPDATE proveedores SET nombre = ?, direccion = ?, telefono = ?, email = ?, fecha_registro = ? WHERE proveedor_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssissi", $nombre, $direccion, $telefono, $email, $fecha_registro, $proveedor_id);
        return $stmt->execute();
    }

    // Eliminar un proveedor
    public function eliminar($proveedor_id) {
        $sql = "DELETE FROM proveedores WHERE proveedor_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $proveedor_id);
        return $stmt->execute();
    }
}
?>