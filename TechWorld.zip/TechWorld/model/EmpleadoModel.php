<?php
require_once '../db/techworld.php';

class EmpleadoModel {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    // Insertar un empleado
    public function insertar($nombre, $puesto, $salario, $fecha_ingreso) {
        $sql = "INSERT INTO empleados (nombre, puesto, salario, fecha_ingreso) VALUES (?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssds", $nombre, $puesto, $salario, $fecha_ingreso);
        return $stmt->execute();
    }

    // Obtener todos los empleados
    public function obtenerTodos() {
        $sql = "SELECT * FROM empleados";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Obtener un empleado por nombre
    public function obtenerPorNombre($nombre) {
        $sql = "SELECT * FROM empleados WHERE nombre LIKE ?";
        $stmt = $this->conn->prepare($sql);
        $nombre = "%" . $nombre . "%";
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Actualizar un empleado
    public function actualizar($empleado_id, $nombre, $puesto, $salario, $fecha_ingreso) {
        $sql = "UPDATE empleados SET nombre = ?, puesto = ?, salario = ?, fecha_ingreso = ? WHERE empleado_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssdsi", $nombre, $puesto, $salario, $fecha_ingreso, $empleado_id);
        return $stmt->execute();
    }

    // Eliminar un empleado
    public function eliminar($empleado_id) {
        $sql = "DELETE FROM empleados WHERE empleado_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $empleado_id);
        return $stmt->execute();
    }
}
?>